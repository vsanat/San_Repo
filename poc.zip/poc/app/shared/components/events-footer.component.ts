import {Component} from '@angular/core'

@Component({
    selector:'events-footer',
    templateUrl:'app/shared/views/events-footer.component.html'
})

export class EventsFooterComponent{
    
}