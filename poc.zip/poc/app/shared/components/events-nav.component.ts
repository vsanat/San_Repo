import {Component} from '@angular/core'

@Component({
    selector:'events-navigation',
    templateUrl:'app/shared/views/events-nav.component.html'
})

export class EventsNavComponent{
    
}