import { PipeTransform, Pipe } from '@angular/core'
import { Event } from '../../syn-events/models/Event'

@Pipe({
    name: 'eventFilter'
})

export class EventFilterPipe implements PipeTransform {
    transform(value: Event[], args: string[]): Event[] {
        let filter: string = args[0] ? args[0].toLocaleLowerCase() : null;
        return filter ? value.filter((event: Event) => event.eventtName.toLocaleLowerCase().indexOf(filter) != -1) : value;
    }
}