"use strict";
var router_1 = require('@angular/router');
var defaultRoute = [
    {
        path: '',
        loadChildren: 'app/syn-home/home.module#HomeModule'
    }
];
var eventsRoute = [
    {
        path: 'events',
        loadChildren: 'app/syn-events/events.module#EventModule'
    }
];
var homeRoute = [
    {
        path: 'home',
        loadChildren: 'app/syn-home/home.module#HomeModule'
    }
];
var appRoutes = defaultRoute.concat(homeRoute, eventsRoute);
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.route.js.map