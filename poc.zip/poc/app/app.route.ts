import { ModuleWithProviders } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'

const defaultRoute: Routes = [      
    {
        path:'',
        loadChildren:'app/syn-home/home.module#HomeModule'
    }
];

const eventsRoute: Routes = [      
    {
        path:'events',
        loadChildren: 'app/syn-events/events.module#EventModule'
    }
];

const homeRoute: Routes = [      
    {
        path:'home',
        loadChildren:'app/syn-home/home.module#HomeModule'
    }
];

const appRoutes: Routes =[
    ...defaultRoute,
    ...homeRoute,
    ...eventsRoute
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);