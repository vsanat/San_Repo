"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('./home.component');
var homeRouteConfigs = [
    {
        path: '',
        component: home_component_1.HomeComponent
    }
];
exports.homeRouting = router_1.RouterModule.forChild(homeRouteConfigs);
//# sourceMappingURL=home.routing.js.map