import{Component} from '@angular/core'


@Component({
    selector:'home-event',
    templateUrl:'app/syn-home/home.component.html'
})

export class HomeComponent{}    