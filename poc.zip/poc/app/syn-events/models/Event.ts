export class Event {
    
        eventId: number;
        eventtName: string;
        eventtCode: string;
        releaseDate: string;
        description: string;
        fees:  number;
        popularity:  number;
        imageUrl: string;
    
}