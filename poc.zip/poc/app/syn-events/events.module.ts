import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http'
import { FormsModule } from '@angular/forms'

import { EventDetailsComponent } from './components/event-details.component';
import { EventComponent } from './components/event-list.component';
import { NewEventComponent } from './components/new-event.component';

import { EventsService } from './services/event.service'

import { eventRouting } from './events.routing'

import {EventFilterPipe} from '../shared/filters/event-filter.pipe'
import {FirstLetterCapitalPipe} from '../shared/filters/first-letter-capital.pipe'

@NgModule({
    exports: [EventComponent],  
    imports: [HttpModule,
        FormsModule, CommonModule, eventRouting],
    declarations: [EventComponent, EventDetailsComponent, NewEventComponent, EventFilterPipe, FirstLetterCapitalPipe],
    providers: [EventsService]
})

export class EventModule { }

