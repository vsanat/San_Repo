"use strict";
var router_1 = require('@angular/router');
var event_details_component_1 = require('./components/event-details.component');
var event_list_component_1 = require('./components/event-list.component');
var new_event_component_1 = require('./components/new-event.component');
var eventRouteConfigs = [
    {
        path: 'newevent',
        component: new_event_component_1.NewEventComponent
    },
    {
        path: ':id',
        component: event_details_component_1.EventDetailsComponent,
    },
    {
        path: '',
        component: event_list_component_1.EventComponent
    }
];
exports.eventRouting = router_1.RouterModule.forChild(eventRouteConfigs);
//# sourceMappingURL=events.routing.js.map