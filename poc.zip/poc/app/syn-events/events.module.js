"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var http_1 = require('@angular/http');
var forms_1 = require('@angular/forms');
var event_details_component_1 = require('./components/event-details.component');
var event_list_component_1 = require('./components/event-list.component');
var new_event_component_1 = require('./components/new-event.component');
var event_service_1 = require('./services/event.service');
var events_routing_1 = require('./events.routing');
var event_filter_pipe_1 = require('../shared/filters/event-filter.pipe');
var first_letter_capital_pipe_1 = require('../shared/filters/first-letter-capital.pipe');
var EventModule = (function () {
    function EventModule() {
    }
    EventModule = __decorate([
        core_1.NgModule({
            exports: [event_list_component_1.EventComponent],
            imports: [http_1.HttpModule,
                forms_1.FormsModule, common_1.CommonModule, events_routing_1.eventRouting],
            declarations: [event_list_component_1.EventComponent, event_details_component_1.EventDetailsComponent, new_event_component_1.NewEventComponent, event_filter_pipe_1.EventFilterPipe, first_letter_capital_pipe_1.FirstLetterCapitalPipe],
            providers: [event_service_1.EventsService]
        }), 
        __metadata('design:paramtypes', [])
    ], EventModule);
    return EventModule;
}());
exports.EventModule = EventModule;
//# sourceMappingURL=events.module.js.map