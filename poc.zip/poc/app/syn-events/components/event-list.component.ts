import { Component, OnInit } from '@angular/core'
import { Event } from '../models/Event'
import { EventsService } from '../services/event.service'

@Component({
    selector: 'events-list',
    templateUrl: 'app/syn-events/views/event-list.component.html'
})
export class EventComponent implements OnInit {
    eventList: Event[];
    filterBy : string ="";
    pageTitle: string = "Synechron";

    constructor(private _eventService: EventsService) { }
    
    ngOnInit(): void {
        this.eventList = this._eventService.getAllEvents();
    }    
}
