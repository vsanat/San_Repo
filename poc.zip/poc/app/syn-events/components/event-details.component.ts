import { Component, OnInit } from '@angular/core'
import { ActivatedRoute, Params } from '@angular/router'

import { Event } from '../models/Event'
import { EventsService } from '../services/event.service'

@Component({
    selector: 'events-details',
    templateUrl: 'app/syn-events/views/event-details.component.html'
})

export class EventDetailsComponent implements OnInit {

    pageTitle: string = "Syn Event Details";
    imageHeight: number = 150;
    imageWidth: number = 300;
    eventDetails: Event = new Event();
    id:number;
filterBy : string ="";
    constructor(private _eventService: EventsService, private _activatedRoute: ActivatedRoute) { }

    ngOnInit(): void {    
        this._activatedRoute.params.subscribe(params =>{
            this.id = params['id']
            console.log(this.id);
        });
        this.eventDetails = this._eventService.getSingleEvent(this.id);
    }
    
}