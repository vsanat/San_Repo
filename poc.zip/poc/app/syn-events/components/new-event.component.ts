import{Component} from '@angular/core'
import{Event} from '../models/Event'
import {EventsService} from '../services/event.service'

@Component({
    selector:'new-event',
    templateUrl:'app/syn-events/views/new-event.component.html'
})

export class NewEventComponent{
    newEvent : Event  = new Event();
    pageTitle: string = "Register new event";

    constructor(private _eventServie : EventsService) {}

    registerEvent(): void{        
        this._eventServie.registerNewEvent(this.newEvent);
    }
}