import { ModuleWithProviders } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'

import {EventDetailsComponent} from './components/event-details.component';
import {EventComponent} from './components/event-list.component';
import {NewEventComponent} from './components/new-event.component';

const eventRouteConfigs : Routes = [
     
    {
        path:'newevent',
        component:NewEventComponent
    },
    {
        path:':id',
        component: EventDetailsComponent,        
    },
    {
        path:'',
        component: EventComponent
    }
    
];

export const eventRouting : ModuleWithProviders = RouterModule.forChild(eventRouteConfigs);