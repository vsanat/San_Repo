import { Injectable } from '@angular/core'
import { Event } from '../models/Event'

@Injectable()
export class EventsService {
    private eventList: Event[] = [{
        "eventId": 1,
        "eventtName": "Angular 2 - Seminar",
        "eventtCode": "NG-SEMI234",
        "releaseDate": "Dec 31, 2016",
        "description": "Angular 2 - Introduction to New features in Angular 2.",
        "fees": 500,
        "popularity": 4.2,
        "imageUrl": "app/shared/images/ang.png"
    },
    {
        "eventId": 2,
        "eventtName": "jQuery 3 - Seminar",
        "eventtCode": "JQ-SEMI424",
        "releaseDate": "Jan 3, 2017",
        "description": "jQuery 3 - Introduction to New features in jQuery 3.",
        "fees": 300,
        "popularity": 3.2,
        "imageUrl": "app/shared/images/ang.png"
    },
    {
        "eventId": 3,
        "eventtName": "Angular 2 - Best Practices",
        "eventtCode": "NG-PNP279",
        "releaseDate": "Jan 7, 2017",
        "description": "Angular 2 - Patterns and Practices and how to write best code.",
        "fees": 700,
        "popularity": 4.4,
        "imageUrl": "app/shared/images/ang.png"
    },
    {
        "eventId": 4,
        "eventtName": "Angular 2 - Migration",
        "eventtCode": "NG-MI377",
        "releaseDate": "Jan 23, 2017",
        "description": "Angular 2 - Migration from Angular JS 1.x to Angular 2.",
        "fees": 900,
        "popularity": 4.9,
        "imageUrl": "app/shared/images/ang.png"
    },
    {
        "eventId": 5,
        "eventtName": "Angular 2 - Rapid Fire",
        "eventtCode": "NG-RF945",
        "releaseDate": "Jan 30, 2017",
        "description": "Angular 2 - Rapid Fire Session on Angular 2.",
        "fees": 300,
        "popularity": 3.3,
        "imageUrl": "app/shared/images/ang.png"
    }];

    getAllEvents(): Event[] {
        return this.eventList;
    }

    getSingleEvent(id: number): Event {
      return this.search(this.eventList, "eventId", id)
    }
    
    registerNewEvent(newEvent:Event):void{
        this.eventList.push(newEvent);
        console.log(this.eventList);
    }

    private search(arraytosearch: Event[], key:string, valuetosearch: number){
        for(var i = 0; i<arraytosearch.length; i++){
            if(arraytosearch[i][key]==valuetosearch){
                return arraytosearch[i];
            }
        }
        return null;
    }

    // mysearch(arraytosearch: Event[], valuetosearch: number){
    //    return arraytosearch.filter(x =>{x.eventId==valuetosearch})
    // }
}