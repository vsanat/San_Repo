"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var EventsService = (function () {
    function EventsService() {
        this.eventList = [{
                "eventId": 1,
                "eventtName": "Angular 2 - Seminar",
                "eventtCode": "NG-SEMI234",
                "releaseDate": "Dec 31, 2016",
                "description": "Angular 2 - Introduction to New features in Angular 2.",
                "fees": 500,
                "popularity": 4.2,
                "imageUrl": "app/shared/images/ang.png"
            },
            {
                "eventId": 2,
                "eventtName": "jQuery 3 - Seminar",
                "eventtCode": "JQ-SEMI424",
                "releaseDate": "Jan 3, 2017",
                "description": "jQuery 3 - Introduction to New features in jQuery 3.",
                "fees": 300,
                "popularity": 3.2,
                "imageUrl": "app/shared/images/ang.png"
            },
            {
                "eventId": 3,
                "eventtName": "Angular 2 - Best Practices",
                "eventtCode": "NG-PNP279",
                "releaseDate": "Jan 7, 2017",
                "description": "Angular 2 - Patterns and Practices and how to write best code.",
                "fees": 700,
                "popularity": 4.4,
                "imageUrl": "app/shared/images/ang.png"
            },
            {
                "eventId": 4,
                "eventtName": "Angular 2 - Migration",
                "eventtCode": "NG-MI377",
                "releaseDate": "Jan 23, 2017",
                "description": "Angular 2 - Migration from Angular JS 1.x to Angular 2.",
                "fees": 900,
                "popularity": 4.9,
                "imageUrl": "app/shared/images/ang.png"
            },
            {
                "eventId": 5,
                "eventtName": "Angular 2 - Rapid Fire",
                "eventtCode": "NG-RF945",
                "releaseDate": "Jan 30, 2017",
                "description": "Angular 2 - Rapid Fire Session on Angular 2.",
                "fees": 300,
                "popularity": 3.3,
                "imageUrl": "app/shared/images/ang.png"
            }];
    }
    EventsService.prototype.getAllEvents = function () {
        return this.eventList;
    };
    EventsService.prototype.getSingleEvent = function (id) {
        return this.search(this.eventList, "eventId", id);
    };
    EventsService.prototype.registerNewEvent = function (newEvent) {
        this.eventList.push(newEvent);
        console.log(this.eventList);
    };
    EventsService.prototype.search = function (arraytosearch, key, valuetosearch) {
        for (var i = 0; i < arraytosearch.length; i++) {
            if (arraytosearch[i][key] == valuetosearch) {
                return arraytosearch[i];
            }
        }
        return null;
    };
    EventsService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], EventsService);
    return EventsService;
}());
exports.EventsService = EventsService;
//# sourceMappingURL=event.service.js.map