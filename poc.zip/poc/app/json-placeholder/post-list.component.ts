import { Component, OnInit } from '@angular/core'
import { PostService } from '../json-placeholder/post.service'
import { Post } from '../json-placeholder/post'

@Component({
    selector: 'post-list',
    templateUrl: 'app/json-placeholder/post-list.component.html'
})

export class PostListComponent implements OnInit {
    posts: Post[];
    constructor(private _postService: PostService) { }

    ngOnInit(): void {
        this.getPosts();
    }

    getPosts() {
        this._postService.getAllPosts().
            subscribe(data => this.posts = data, error => alert(error), () => console.log("Completed!"));
    }
}