import { Injectable } from '@angular/core'
import { Http, Headers } from '@angular/http'
import { Observable } from 'rxjs'
import "rxjs/add/operator/map";
import { Post } from '../json-placeholder/post'

@Injectable()
export class PostService {

    private uri: string = "https://jsonplaceholder.typicode.com/posts";

    constructor(private _http: Http) { }

    getAllPosts(): Observable<Post[]> {
        return this._http.get(this.uri).map(res => res.json());
    }
}