import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { EventsNavComponent } from './shared/components/events-nav.component'

import {routing} from '../app/app.route'

@NgModule({
  imports: [BrowserModule, routing],
  declarations: [AppComponent, EventsNavComponent],
  bootstrap: [AppComponent],
})

export class AppModule { }