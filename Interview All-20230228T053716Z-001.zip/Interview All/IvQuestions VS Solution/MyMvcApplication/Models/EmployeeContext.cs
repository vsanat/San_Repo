﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MyMvcApplication.Models
{
    public class EntityContext : DbContext
    {
       public DbSet<Employee> employees { get; set; }
       public DbSet<Table1> table1 { get; set; }
       public EntityContext(string connectionString):base
           (connectionString)
       {

       }
    }
}