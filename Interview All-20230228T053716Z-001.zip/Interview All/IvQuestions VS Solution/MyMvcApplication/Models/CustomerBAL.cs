﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace MyMvcApplication.Models
{
    public class CustomerBAL
    {
        public Customer GetCustomer()
        {
            Customer c = new Customer { Name = "cust", Age = 34 };
            return c;
        }
    }
}