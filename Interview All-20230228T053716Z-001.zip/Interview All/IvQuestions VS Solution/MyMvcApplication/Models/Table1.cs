﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MyMvcApplication.Models
{
    [Table("Table1")]
    public class Table1
    {
        public int Id { get; set; }
    }
}