﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyMvcApplication.Models;

namespace MyMvcApplication.Controllers
{
    public class EmployeeController : Controller
    {
        public ActionResult Index()
        {            
            string cons = System.Configuration.ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;

            EntityContext entityContext = new EntityContext(cons);
            List<Employee> employeeList = entityContext.employees.ToList();
            return View(employeeList);
        }

        public ActionResult EmployeeDetails(int id)
        {
            //Employee emp = new Employee() { Id = 1, Name = "Sanat", City = "Bang" };

            //EmployeeContext employeeContext = new EmployeeContext();

            //or

            string cons = System.Configuration.ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;

            EntityContext entityContext = new EntityContext(cons);

            Table1 table1 = entityContext.table1.FirstOrDefault(t1 => t1.Id == id);
            Employee employee = entityContext.employees.Single(e=>e.Id==id);

            return View(employee);
        }
    }
}