﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyMvcApplication.Controllers
{
    public class HomeController : Controller
    {
        public string SanTestMethod(string id, string name1)
        {
            //http://localhost:49468/home/SanTestMethod/10?name1=sanat&name=man
            Response.Write("ID =" + id);
            Response.Write("<br/>");
            Response.Write("Name =" + Request.QueryString["name"]);
            //or
            Response.Write("<br/>");
            Response.Write("Name = " + name1);
            return "";
        }

        public ViewResult Index()
        {
            ViewBag.Title = "Country list";
            
            //indexing can not be applied to viewbag
            //ViewBag["hell"]="helloo";

            ViewBag.Countries = new List<string> { "IND", "USA", "CHN", "JPN" };

            ViewData["Countries"] = new List<string> { "UK", "AUS", "SWE", "FRN" };
            
            return View();
        }
    }
}
