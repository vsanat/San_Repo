﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class Employee
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Salary { get; set; }
        public int Age { get; set; }
        public int DeptId { get; set; }

        public static List<Employee> GetAllEmployees()
        {
            List<Employee> empList = new List<Employee> { new Employee{ID=1,Age=24, FirstName="Ramu", LastName="Kumar",Salary=2000,DeptId=1},
                new Employee{ID=2, Age=25, FirstName="Rama", LastName="Kumar",Salary=3000,DeptId=1},
                new Employee{ID=3,Age=26, FirstName="Ramah", LastName="Kumar",Salary=4000,DeptId=2},
                new Employee{ID=4,Age=27, FirstName="Ramiya", LastName="Kumar",Salary=2000,DeptId=3},
                new Employee{ID=5,Age=28, FirstName="Ramua", LastName="Kumar",Salary=6000,DeptId=2},
                new Employee{ID=6,Age=29, FirstName="Ramusu", LastName="Kumar",Salary=2000,DeptId=1},
            };
            return empList;
            //Employee emp = empList.FirstOrDefault(e=> e.Salary==2000);
        }
    }
}
