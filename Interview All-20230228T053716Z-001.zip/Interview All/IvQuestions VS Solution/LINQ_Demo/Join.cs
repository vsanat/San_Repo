﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class Join
    {
        static void Main1()
        {
            var emp = from d in Departments.GetAllDepartments()
                            join e in Employee.GetAllEmployees()
                            on d.Id equals e.DeptId
                            select new
                            {
                                DeptName = d.Name,
                                Empname = e.FirstName
                            };

            foreach (var em in emp)
            {
                Console.WriteLine(em.Empname +"\t"+em.DeptName);
            }          
        }
    }
}
