﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class Departments
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public static List<Departments> GetAllDepartments()
        {
            List<Departments> deptList = new List<Departments> { new Departments{Id=1, Name="IT"}, new 
            Departments{Id=2,Name="HR"}, new Departments{Id=3, Name="Admin"}};

            return deptList;
        }
    }
}
