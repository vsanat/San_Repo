﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class GroupJoin
    {
        static void Main1()
        {
            var empByDept = from d in Departments.GetAllDepartments()
                            join e in Employee.GetAllEmployees()
                            on d.Id equals e.DeptId into eGroup
                            select new
                            {
                                Dept = d,
                                Emp = eGroup
                            };

            foreach (var department in empByDept)
            {
                Console.WriteLine(department.Dept.Name);
                foreach (var emp in department.Emp)
                {
                    Console.WriteLine("Employee Name = {0}", emp.FirstName+" "+emp.LastName);
                }
                Console.WriteLine();
            }
        }
    }
}
