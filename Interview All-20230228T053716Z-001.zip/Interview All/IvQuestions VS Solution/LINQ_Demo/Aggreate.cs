﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class Aggreate
    {
        static void Main1(string[] args)
        {
            string[] country = { "India", "US", "UK", "Canada", "Australia" };

            string result = string.Empty;

            foreach (var item in country)
            {
                result = result + item + ",";
            }
            int lastindex = result.LastIndexOf(',');
            result = result.Remove(lastindex);
            Console.WriteLine(result);

            //or
            string res = country.Aggregate((a, b) => a + "," + b);
            Console.WriteLine(res);

            //anonymous method
            Func<int, int, int> v1 = (a, b) => { return (a + b); };
            int i = v1(5, 10);
            Console.WriteLine(i);

            int[] nums = { 3, 6, 7, 8 };
            int r1 = nums.Aggregate((a, b) => { return a * b; });
            Console.WriteLine(r1);

            int[] nums1 = { 1, 2, 3, 6, 7, 8 };            
        }
    }
}
