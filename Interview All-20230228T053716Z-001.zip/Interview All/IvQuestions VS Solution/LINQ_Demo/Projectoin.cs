﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class Projectoin
    {
        static void Main1()
        {
            List<Employee> employees = Employee.GetAllEmployees();
            var emps = employees.Where(e=>e.Salary>2000).Select(e => new { e.ID , Name=e.FirstName+" "+e.LastName, e.Age, Bonus = e.Salary*.1});

            foreach (var item in emps)
            {
                Console.WriteLine("Name{0}, Bonus={1}",item.Name,item.Bonus);
            }
            Console.Read();
        }
    }
}
