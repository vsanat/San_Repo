﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQ_Demo
{
    class LeftJoin
    {
        static void Main()
        {
            //emp with no dept
            var emp = from e in EmpWithNoDept.GetAllEmployees()
                       join d in Departments.GetAllDepartments()
                       on e.DeptId equals d.Id into eg
                       from d in eg.DefaultIfEmpty()
                       select new
                       {
                           DeptName = d == null ? "No Dept" : d.Name,
                           Empname = e.FirstName
                       };

            foreach (var em in emp)
            {
                Console.WriteLine(em.Empname + "\t" + em.DeptName);
            }
        }
    }
}
