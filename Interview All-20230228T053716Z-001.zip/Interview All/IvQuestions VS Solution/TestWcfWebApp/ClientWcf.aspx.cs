﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestWcfWebApp
{
    public partial class ClientWcf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGetData_Click(object sender, EventArgs e)
        {
            MyWcfService.Service1Client sc = new MyWcfService.Service1Client();
            string strServiceData = sc.GetData(txtInout.Text);
            lblMessage.Text = strServiceData;
        }
    }
}