﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
    }

    class ClsChangeEmp
    {
        List<Employee> elist = new List<Employee>();

        public ClsChangeEmp()
        {
            elist.Add(new Employee() { EmpId = 111, EmpName = "Aaa" });
            elist.Add(new Employee() { EmpId = 222, EmpName = "Bbb" });
            elist.Add(new Employee() { EmpId = 333, EmpName = "Ccc" });
        }

        public string this[int eid]
        {
            get { return elist.FirstOrDefault(e => e.EmpId == eid).EmpName; }
            set { elist.FirstOrDefault(e => e.EmpId == eid).EmpName = value; }
        }
    }

    class IndexersExample
    {
        static void Main1()
        {
            ClsChangeEmp chEmp = new ClsChangeEmp();
            Console.WriteLine("EmpName = {0}", chEmp[111]);
            Console.WriteLine("EmpName = {0}", chEmp[222]);
            Console.WriteLine("EmpName = {0}", chEmp[333]);

            chEmp[111] = "San";
            chEmp[222] = "Man";
            chEmp[333] = "Wan";

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Changed EmpName = {0}", chEmp[111]);
            Console.WriteLine("Changed EmpName = {0}", chEmp[222]);
            Console.WriteLine("Changed EmpName = {0}", chEmp[333]);

            Console.Read();
        }
    }
}
