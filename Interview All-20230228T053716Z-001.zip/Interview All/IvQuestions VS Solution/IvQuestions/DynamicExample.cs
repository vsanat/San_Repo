﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class DynamicExample
    {
        static void Main1()
        {
            //if (!true)
            //{ Console.WriteLine("h"); }
            dynamic c = "hello";
            c++; //this will give runtime exception
            c = 3;
            c = 3.3;
            c = 'h';           
        }
    }
}
