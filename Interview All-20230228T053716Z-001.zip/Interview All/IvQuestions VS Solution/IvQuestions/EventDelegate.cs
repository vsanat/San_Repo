﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    public delegate void MyDeligate(object sender, EventArgs e);
    class EventDelegateExample
    {
        public event MyDeligate MyEvent;

        //event handler
        public void MyFunction(object sender, EventArgs e)
        {
            Console.WriteLine("MyFunction called: " + sender); 
        }

        public static void Main1()
        {
            EventDelegateExample evd = new EventDelegateExample();

            MyDeligate myDel = new MyDeligate(evd.MyFunction);
            evd.MyEvent += evd.MyFunction;
            evd.MyEvent += evd_MyEvent;

            object o = new object();
            EventArgs e = new EventArgs();
            evd.MyEvent(o, e);

            Console.Read();
        }

        static void evd_MyEvent(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

    }
}
