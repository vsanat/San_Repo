﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    static class ExtentionMethod
    {
        public static readonly int i;

        static void Main1()
        {
            //int i = 1;
            //delegate o = (int x, string s) => s.Length > x;
            var v = new List<object> { "1", 1 };
            var min = 1;
            foreach (int i in min.Squares(4))
            { Console.WriteLine(i); }

            Console.Read();
        }

        static IEnumerable Squares(this int from, int to)
        {
            for (int i = from; i <= to; i++)
                yield return (int)i * i;
        }
    }
}
