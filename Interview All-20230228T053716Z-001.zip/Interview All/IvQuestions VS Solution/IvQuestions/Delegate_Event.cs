﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    
    class MyClasss
    {
        public delegate void MyDelegate(int i);
        public event MyDelegate LogEvent; // event cant be defined out side the class

        public void MyFun(int i)
        {
           Console.WriteLine(i);
        }

        public void Test()
        {
            MyDelegate md = new MyDelegate(MyFun);
            md.BeginInvoke(4, null, null);
            //md.EndInvoke(5);
        }

        public event EventHandler MyEvent
        {
            add { Console.WriteLine("Add operation"); }
            remove { Console.WriteLine("remove operation"); }
        }
        
        public void MyEventHandler(object sender, EventArgs e)
        {

        }

        public static void Main1(string[] args)
        {
            MyClasss mycls = new MyClasss();            
            mycls.LogEvent += new MyDelegate(mycls.MyFun);
            mycls.LogEvent(5);

            //unsubscribing the event
            mycls.LogEvent -= new MyDelegate(mycls.MyFun);
            //de.Log(5); //now it is not possible

            mycls.Test();
            mycls.MyEvent += new EventHandler(mycls.MyEventHandler);
            mycls.MyEvent -= null;
            Console.Read();
        }
    }
}
