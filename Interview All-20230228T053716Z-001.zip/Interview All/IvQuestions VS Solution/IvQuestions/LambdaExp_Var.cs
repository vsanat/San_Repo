﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class Emp
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    class LambdaExp_Var
    {
        static void Main1()
        {
            Emp em = new Emp() { Id = 1, Name = "San" };

            List<Emp> emLst = new List<Emp>() { new Emp(){Id=2,Name="Man"},
            new Emp(){Id=3,Name="Wan123"}};

            emLst.Add(em);
            
            Emp fndRes = emLst.Find(e => e.Name == "San");

            Console.WriteLine(fndRes.Name);

            if (emLst.Any(e => e.Name.Equals("San")))
                Console.WriteLine(true);

            //use of var keyword 
            object o = from x in emLst where x.Name.Length > 5 select new {x.Name, x.Id};

            //foreach (var item in o) //this is not possible directly, you have to bind Name and Id property to some class in order to iterate
            //{
            //   item.
            //}

            var v = emLst.Where(e=>e.Name.Length > 5);

            foreach (var item in v)
            {
                Console.WriteLine(item.Name);
            }

            Console.Read();            
        }
    }
}
