﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class A
    {
        public virtual void Foo() { Console.WriteLine("A::Foo()"); }
    }

    class B : A
    {
        //public override new void Foo() { Console.WriteLine("B::Foo()"); }
        public virtual new void Foo() { Console.WriteLine("B::Foo()"); }
    }

    class Test:B
    {
        static void Main1(string[] args)
        {
            //A a;
            //B b;

            //a = new A();
            //b = new B();
            //a.Foo();  // output --> "A::Foo()"
            //b.Foo();  // output --> "B::Foo()"

            //a = new B();
            //a.Foo();  // output --> "B::Foo()"

            Test t = new Test();
            t.Foo();

            B b = new Test();

            Console.Read();
        }
        //public override void Foo()
        //{ Console.WriteLine("c: foo"); }
        public new void Foo()
        { Console.WriteLine("c: foo"); }

    }
}
