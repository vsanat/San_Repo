﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IvQuestions
{
    class AsyncAndAwait
    {
        static void Main1()
        {
            Console.WriteLine("Main started");

            Fun();

            Console.WriteLine("Main end");
        }

        static async void Fun()
        {
            Console.WriteLine("Fun started");
            //LongFun(); // we will start this in parallel thread
            await Task.Run(new Action(LongFun));
            Console.WriteLine("Fun end");
        }


        //static void Fun()
        //{
        //    Console.WriteLine("Fun started");
        //    LongFun(); // we will start this in parallel thread
        //    //await Task.Run(new Action(LongFun));
        //    Console.WriteLine("Fun end");
        //}

        static void LongFun()
        {
            Console.WriteLine("Long run started");
            Thread.Sleep(5000);
            Console.WriteLine("Long run end");
        }
    }
}
