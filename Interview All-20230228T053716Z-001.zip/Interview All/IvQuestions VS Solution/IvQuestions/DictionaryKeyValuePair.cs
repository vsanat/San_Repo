﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class Employees
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Salary { get; set; }
    }

    class DictionaryKeyValuePair
    {
        public static void Main1()
        {
            Dictionary<int, Employees> empDictionary = new Dictionary<int, Employees>();
            empDictionary.Add(111, new Employees() { EmpId = 111, EmpName = "Aaa", Salary = 2000 });
            empDictionary.Add(222, new Employees() { EmpId = 222, EmpName = "Bbb", Salary = 3000 });
            empDictionary.Add(333, new Employees() { EmpId = 333, EmpName = "Bbb", Salary = 5000 });

            foreach (KeyValuePair<int, Employees> emp in empDictionary)
            {
                Console.WriteLine("EmpId = {0}, EmpName = {1}, Salary = {2}", emp.Key, emp.Value.EmpName, emp.Value.Salary);
                Console.WriteLine("_____________________________________________________________");
            }
            Console.Read();
        }
    }
}
