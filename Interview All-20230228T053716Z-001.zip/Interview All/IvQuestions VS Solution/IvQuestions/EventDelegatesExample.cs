﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    using System;

    namespace BusinessObjects
    {
        public delegate void BusinessObjectEventHandler(object sender, BusinessObjectEventArgs e);

        public class Invoice
        {
            private string strInvoiceID;
            private System.DateTime dtmDateRaised;

            public event BusinessObjectEventHandler OnChanged;

            public Invoice()
            {
            }

            public string InvoiceID
            {
                get
                {
                    return this.strInvoiceID;
                }
                set
                {
                    if (OnChanged != null)
                    {
                        OnChanged(this, new BusinessObjectEventArgs("invoiceID", this.strInvoiceID, value));
                    }
                    this.strInvoiceID = value;
                }
            }

            public System.DateTime DateRaised
            {
                get
                {
                    return this.dtmDateRaised;
                }
                set
                {
                    if (OnChanged != null)
                    {
                        OnChanged(this, new BusinessObjectEventArgs("dateRaised", this.dtmDateRaised, value));
                    }
                    this.dtmDateRaised = value;
                }
            }            
        }

        public class BusinessObjectEventArgs : EventArgs
        {
            private string strPropertyName;
            private object objOldValue;
            private object objNewValue;

            public BusinessObjectEventArgs(string PropertyName, object OldValue, object NewValue)
            {
                this.strPropertyName = PropertyName;
                this.objOldValue = OldValue;
                this.objNewValue = NewValue;
            }

            public string PropertyName
            {
                get
                {
                    return this.strPropertyName;
                }
            }

            public object OldValue
            {
                get
                {
                    return this.objOldValue;
                }
            }

            public object NewValue
            {
                get
                {
                    return this.objNewValue;
                }
            }
        }

        public class CallInvoice
        {
            private void AnInvoiceClient()
            {
                BusinessObjects.Invoice i = new Invoice();
                i.OnChanged += new BusinessObjectEventHandler(i_OnChanged1);            
                i.InvoiceID = "1";
                i.DateRaised = System.DateTime.Now;                                   
            }

            private void i_OnChanged1(object sender, BusinessObjectEventArgs e)
            {
                string strMsg = "object {0} property " +
                                    "{1} changed from {2} to {3}";
                BusinessObjects.Invoice i = (Invoice)sender;
                Console.WriteLine(String.Format(strMsg,
                                      i.InvoiceID, e.PropertyName,
                                      e.OldValue, e.NewValue));
            }

            public static void Main1()
            {
                CallInvoice callinv = new CallInvoice();
                callinv.AnInvoiceClient();

                Console.Read();
            }
        }
    }

}
