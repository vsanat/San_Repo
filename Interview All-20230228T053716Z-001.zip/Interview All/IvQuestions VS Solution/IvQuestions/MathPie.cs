﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class MathPie
    {
        static void Main1()
        {
            ArrayList list = new ArrayList();

            var item1 = "Math.PI=";
            var item2 = Math.PI;
            var itme3 = ';';

            list.Add(item1);
            list.Add(item2);
            list.Add(itme3);

            foreach(var ite in list)
                Console.Write(ite);
        }
    }
}
