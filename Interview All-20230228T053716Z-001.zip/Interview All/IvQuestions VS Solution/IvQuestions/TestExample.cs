﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class TestExample
    {
        static void Main2()
        {
            string st = "sanat";

            char[] ch = st.ToArray();
            //IEnumerable<char> chr = ch.Reverse();
            //foreach (var item in chr)
            //{
            //    Console.Write(item.ToString());
            //}

            //IEnumerable<char> chr = st.Reverse();
            //foreach (var item in chr)
            //{
            //    Console.Write(item.ToString());
            //}


            //Array.Reverse(ch);            
            //Console.WriteLine(new string(ch));
            //Console.Read();

            //using stack
            //Stack<char> stch = new Stack<char>();
            //for (int i = 0; i < 5; i++)
            //{
            //    stch.Push(ch[i]);
            //}
            //for (int i = 0; i < 5; i++)
            //{
            //  ch[i] =  stch.Pop();
            //}
            //st = new string(ch);
            //Console.WriteLine(st);



            Console.Read();
        }
    }
}
