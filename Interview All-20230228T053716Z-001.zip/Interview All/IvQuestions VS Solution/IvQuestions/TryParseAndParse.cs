﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class TryParseAndParse
    {        
        static void Main1()
        {
            string s = "s";

            //int i = int.Parse(s); //this will give format exception
            //Console.WriteLine(i);

            int j;
            bool res = int.TryParse(s, out j); //this will give 0 if any wrongly formated value comes in input with return false
            Console.WriteLine(j);

            //Parse and TryParse only takes string as input
            //convert can take any type of input value
            int k = Convert.ToInt32(s);
            Console.WriteLine(k);

            Console.Read();
        }
    }
}
