﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class UsingStatement
    {
        public void fun()
        {
            using (TextWriter w = File.CreateText("log.txt"))
            {
                w.WriteLine("This is line one");
                //w.Dispose
            }

            ////class which implements IDisposable can be written here
            //using (string w = new string())
            //{
            //    w.WriteLine("This is line one");
            //    //w.Dispose
            //}
        }
    }
}
