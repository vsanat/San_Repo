﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace InterviewQuestions
{
    [Serializable]
    class Employee : ISerializable
    {
        public Employee(){}
        public int EmpId { get; set; }
        public string EmpName { get; set; }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("EmpName",typeof(string));
            info.AddValue("EmpId", typeof(int));
        }

        public Employee(SerializationInfo info)
        { EmpId = (int)info.GetValue("EmpId",typeof(int)); }
    }

    class Serialization
    {
        public static void Main1()
        {
            Employee em = new Employee{EmpId=1, EmpName="san"};

            Stream stream = File.Open("myfile.osl",FileMode.Create);
            BinaryFormatter binformat = new BinaryFormatter();
            binformat.Serialize(stream, em);
        }
    }
}
