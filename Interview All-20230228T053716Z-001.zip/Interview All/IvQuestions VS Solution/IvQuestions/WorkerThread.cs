﻿using System.Threading;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class WorkerThread
    {
        public delegate void MyDel();
        
        private static void Fun1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("hello fun1");
            }
        }

        public static void Main1()
        {
            WorkerThread wt = new WorkerThread();
            MyDel md = new MyDel(Fun1);
            IAsyncResult res = md.BeginInvoke(null,null);

            while (!res.IsCompleted)
            {
                Console.WriteLine("hello kkkkkkkkkkkkkk");
            }

            Console.Read();
        }
    }
}
