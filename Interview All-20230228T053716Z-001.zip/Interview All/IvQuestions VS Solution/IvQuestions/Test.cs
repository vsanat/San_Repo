﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Fun
    {
        public Fun()
        {
            Console.WriteLine("non static fun");
        }

        static Fun()
        {
            Console.WriteLine("static fun");
        }

        public Fun(int i)
        {
            Console.WriteLine("non static fun");
        }

        ////static constructor cant have parameters
        //static Fun(int i)
        //{
        //    Console.WriteLine("non static fun");
        //}

        public void test() { }
        //public int test() { return 1; }

        public void test(int i) { Console.WriteLine("int"); }
        public void test(double i) { Console.WriteLine("double"); }

        public static void Main1(string[] args)
        {
            Fun fun = new Fun();
            fun.test(123.8);
            Console.Read();
        }
    }
}
