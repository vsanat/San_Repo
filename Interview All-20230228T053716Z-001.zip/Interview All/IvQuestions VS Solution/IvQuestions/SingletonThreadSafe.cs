﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    sealed class Singleton
    {
        //this approach is fine if multiple thread are not there
        private Singleton() { }

        private static readonly Singleton mySt = new Singleton();

        public Singleton MyStObj
        {
            get
            {
                return mySt;
            }
        }
    }

    sealed class SingletonThreadSafe
    {
        private SingletonThreadSafe() { }

        //private static readonly SingletonThreadSafe singleObj;
        private static volatile SingletonThreadSafe singleObj;
        private static object syncobj = new object();

        public string st = "sanat";

        public static SingletonThreadSafe GetsingleObj
        {
            get
            {
                lock (syncobj)
                {
                    if (singleObj == null)
                    {
                        //as its volatile we can assign it here, its not possible if it is readonly
                        singleObj = new SingletonThreadSafe();
                    }
                    return singleObj;
                }
            }
        }
    }

    public class Test
    {
        static void Main1(string[] args)
        {
            SingletonThreadSafe stts = SingletonThreadSafe.GetsingleObj;
            Console.WriteLine(stts.st);
            Console.Read();
        }
    }

}
