using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class FuncDelegate
    {


        static void Main1()
        {
            Employee e1 = new Employee() { EmpId = 1, EmpName = "San" };
            Employee e2 = new Employee() { EmpId = 2, EmpName = "Man" };
            Employee e3 = new Employee() { EmpId = 3, EmpName = "Wan" };
            Employee e4 = new Employee() { EmpId = 4, EmpName = "Dan" };

            List<Employee> emp = new List<Employee>() { e1, e2, e3, e4 };
			
			//object initialization
			//List<Employee> emp = new List<Employee>(){new Employee{ EmpId = 1, EmpName = "San" },new Employee{ EmpId = 2, EmpName = "Man" }};

            Func<Employee, string> selectEmp = (employee) => "Name: " + employee.EmpName;

            IEnumerable<string> empname1 = emp.Select(selectEmp);

            foreach (string item in empname1)
            {
                Console.WriteLine(item);
            }  

            // or
            IEnumerable<string> empname = emp.Select(e=> "Name: " + e.EmpName);

            foreach (string item in empname)
            {
                Console.WriteLine(item);
            }

            Func<int, int, int> sumNum = (fnumber, lnumber) =>
            {
                fnumber = 1;
                lnumber = 5;
                return fnumber + lnumber;
            };

            Console.WriteLine(sumNum(20, 30));

            //hashtable is not type safe, we can insert any value in the hashtable  
            Hashtable htbl = new Hashtable();
            htbl.Add(12, "San");
            htbl.Add("Man", "San");
            htbl.Add(12.4, "Dan");
            
            var rt = htbl.Values;
            foreach (var item in rt)
            {
                Console.WriteLine(item);
            }

            var rt1 = htbl.Keys;
            foreach (var item in rt1)
            {
                Console.WriteLine(item);
            }            
        }
    }
}
