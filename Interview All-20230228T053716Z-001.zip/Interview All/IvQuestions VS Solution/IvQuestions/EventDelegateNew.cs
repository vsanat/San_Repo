﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public delegate int MyDelegate(int i);

    class EventDelegateNew
    {
        public event MyDelegate MyEvent;

        public int MyFun(int i)
        {
            Console.WriteLine(i);
            return i * 5;
        }

        public static void Main1(string[] args)
        {
            EventDelegateNew ed = new EventDelegateNew();

            ed.MyEvent += new MyDelegate(ed.MyFun);
            //or
            ed.MyEvent += ed.MyFun;

            int i = ed.MyEvent(5);
            
            Console.Read();
        }
    }
}
