﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class Emplos : IComparable<Emplos>
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Salary { get; set; }

        public int CompareTo(Emplos other)
        {
            if (this.Salary > other.Salary)
                return 1;
            if (this.Salary < other.Salary)
                return -1;
            return 0;
        }
    }

    class SortList
    {
        static void Main1()
        {
            Emplos e1 = new Emplos() { EmpId = 1, EmpName = "San", Salary = 2000 };
            Emplos e2 = new Emplos() { EmpId = 2, EmpName = "Man", Salary = 6000 };
            Emplos e3 = new Emplos() { EmpId = 3, EmpName = "Wan", Salary = 4000 };
            Emplos e4 = new Emplos() { EmpId = 4, EmpName = "Dan", Salary = 7000 };

            List<Emplos> emlist = new List<Emplos>() { e1, e2, e3, e4 };

            Console.WriteLine("before sorting");
            foreach (Emplos emp in emlist)
            {
                Console.WriteLine("Name = {0}, Salary = {1}", emp.EmpName, emp.Salary);
            }

            //for sorting functionality we need to implemt IComparable intercae CompareTo method
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ascending order");
            emlist.Sort();
            foreach (Emplos emp in emlist)
            {
                Console.WriteLine("Name = {0}, Salary = {1}", emp.EmpName, emp.Salary);
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("descending order");
            emlist.Reverse();
            foreach (Emplos emp in emlist)
            {
                Console.WriteLine("Name = {0}, Salary = {1}", emp.EmpName, emp.Salary);
            }

            Console.Read();
        }
    }
}
