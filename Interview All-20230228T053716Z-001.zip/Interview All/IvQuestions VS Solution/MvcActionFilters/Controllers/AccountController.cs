﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcActionFilters.Controllers
{
    public class AccountController : Controller
    {
        //
        // GET: /Account/
        [ActionName("Login  ")]
        //[ActionName("Logon")]
        //[ActionName("Log")]
        public ActionResult Login()
        {
            return View();
        }

    }
}
