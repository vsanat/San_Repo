﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebServiceDemo
{
    public partial class WebFormClient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.MyWebServiceSoapClient hnc = new ServiceReference1.MyWebServiceSoapClient();
            Label1.Text = hnc.HelloName(TextBox1.Text);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ServiceReference2.MyWCFServiceClient hnc2 = new ServiceReference2.MyWCFServiceClient();
            Label2.Text = hnc2.HelloName(TextBox2.Text);
        }
    }

}