﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcVenkat.Models;
using System.Configuration;
using System.Data.SqlClient;

namespace MvcVenkat.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/
        string conn = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;

        [Authorize]
        public ActionResult Index()
        {
            string conn = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;
            EmployeeContext employeeContext = new EmployeeContext(conn);
            List<Employee> employeeList = employeeContext.Employees.ToList();
            return View(employeeList);
        }

        //
        // GET: /Employee/Details/5

        public ActionResult Details([Bind()]int id)
        {
            string conn = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;
            EmployeeContext employeeContext = new EmployeeContext(conn);
            Employee employee = employeeContext.Employees.FirstOrDefault(e => e.Id == id);
            return View(employee);
        }

        //
        // GET: /Employee/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Employee/Create        

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            //UpdateModel(emp, new string[] { "Name", "City" }); //include properties
            //UpdateModel(emp, null, null, new string[] { "ID"}); //exclude properties
            CreateEmployee(emp);
            return RedirectToAction("index");
        }

        public void UpdateEmployee(Employee emp)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString);
            SqlCommand cmd = new SqlCommand("update Employee set city = @city where id =@id", conn);
            cmd.Parameters.AddWithValue("@id", emp.Id);
            cmd.Parameters.AddWithValue("@city", emp.City);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void CreateEmployee(Employee emp)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString);
            SqlCommand cmd = new SqlCommand("insert into Employee values(@id,@name,@city)", conn);
            cmd.Parameters.AddWithValue("@id", emp.Id);
            cmd.Parameters.AddWithValue("@name", emp.Name);
            cmd.Parameters.AddWithValue("@city", emp.City);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public void DeleteEmployee(int id)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString);
            SqlCommand cmd = new SqlCommand("delete from Employee where id  = @id", conn);
            cmd.Parameters.AddWithValue("@id", id);            
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        //
        // GET: /Employee/Edit/5        
        public ActionResult Edit(int id)
        {
            return View();
        }

        //passing emp model
        //[HttpPost]
        //public ActionResult Edit(Employee emp)
        //{
        //    try
        //    {
        //        UpdateEmployee(emp);
        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //using UpdateModel
        //[HttpPost]
        //[ActionName("Edit")]
        //public ActionResult Edit_Emp(int id)
        //{
        //    try
        //    {
        //        EmployeeContext empctx = new EmployeeContext(conn);
        //        Employee emp = empctx.Employees.First(e => e.Id == id);
        //        UpdateModel(emp, new string[]{"id","city"});
        //        UpdateEmployee(emp);
        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        ////using Bind attribute
        //[HttpPost]
        //[ActionName("Edit")]
        //public ActionResult Edit_Emp([Bind(Include="id,city")]Employee emp)
        //{
        //    try
        //    {               
        //        UpdateEmployee(emp);
        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        //using Bind attribute
        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit_Emp(int id)
        {
            try
            {
                EmployeeContext empctx = new EmployeeContext(conn);
                Employee emp = empctx.Employees.First(e => e.Id == id);
                UpdateModel<IEmployee>(emp);
                UpdateEmployee(emp);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            DeleteEmployee(id);
            return RedirectToAction("Index");
        }

        //
        // POST: /Employee/Delete/5

        //[HttpPost]
        //public ActionResult Delete(int id, FormCollection collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here
        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}
