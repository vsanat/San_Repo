﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcVenkat.Models
{
    interface IEmployee
    {
        int Id { get; set; }
        string City { get; set; }
    }
}
