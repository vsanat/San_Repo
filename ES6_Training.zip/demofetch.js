class clsAjax {
    getData() {
        // url (required), options (optional)
        fetch('http://mydataservice001.azurewebsites.net/api/EmployeeInfoRESTAPI', {
                method: 'get', //post,put,delete
                headers: new Headers({'Content-Type': 'application/json'})
            })
            .then(function (response) {
                response
                    .json()
                    .then(function (data) {
                        console.log(JSON.stringify(data));
                    });
                // return response.json();
            })
            .catch(function (err) {
                console.log('Error ' + err);
            });

    }
    saveData() {
        fetch('http://mydataservice001.azurewebsites.net/api/EmployeeInfoRESTAPI', {
            method: 'post',
            headers: {
                "Content-type": "application/x-www-form-urlencoded; charset=UTF-8" 
            },
                body: 
                    'empName=James&salary=12300&deptName=IT&designation=Manager'
                
            })
             .then(function (response) {
                response
                    .json()
                    .then(function (data) {
                        console.log(JSON.stringify(data));
                    });
                // return response.json();
            })
            .catch(function (error) {
                console.log('Request failed', error);
            });
    }
}
