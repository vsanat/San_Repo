(function(){
    console.log('I am IIFE');
})();