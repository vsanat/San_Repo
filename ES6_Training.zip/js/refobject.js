//The function itself invokes constructor
var myObject = function(){
    this.printMessage = function(){
        console.log('print message');
    };
};

var inst1 = new myObject();
inst1.printMessage();

myObject.prototype.extendedFunction=function(){
    console.log('I am Extended Function');
};
inst1.extendedFunction();
