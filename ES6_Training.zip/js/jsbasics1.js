function add(x,y){
    return x+y;
}

console.log("Add  = " + add(4,5));
