//Object literal for Pure DATA Schemas like JSON
var emp = {
    empNo:101,
    empName:'Mahesh'
};
console.log(emp.empNo + '  ' + emp.empName);
emp.empNo = 102;
emp.empName = 'Tejas';
console.log(emp.empNo + '  ' + emp.empName);

//The {} ==> is object literal
//{<KEY>:<VALUE>}
//Single Object
function MyClassObject() {
    function display(){
        console.log('I am Display....');
    }
    return {
        //Publically Accessible
        fn1:function(msg){
            display();
           console.log('Input ' + msg); 
        },
        fn2:function(x,y){
            display();
            return (x*x) + (y*y);
        }
    }
};
var obj = new MyClassObject();
obj.fn1('ES 3');
var res = obj.fn2(10,20);
console.log(res);
//Defing an Extension to an existing fucntion Object using
//prototype
MyClassObject.prototype.extendedFunction1 = function(){
    console.log('I am In extended Function of MyClassObject');
};
obj.extendedFunction1();

 
 