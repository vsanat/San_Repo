class EmployeeBase {
  constructor() {
    this.EmpNo = 0;
    this.EmpName = "";
    this.Salary = 0;
  }
  print() {
      console.log(`EmpNo : ${this.EmpNo} 
                   EmpName: ${this.EmpName}
                   Salary: ${this.Salary}`);
  }
}

class Manager extends EmployeeBase {
  constructor() {
    super(); //Links the base class and derive class
    this.Income = 0;
  }

  getTax() {
    let tax = (this.Salary + this.Income) * 0.2;
    return tax;
  }
}

let mgr = new Manager();
mgr.EmpNo  =101;
mgr.EmpName = 'Tejas';
mgr.Salary  =20000;
mgr.Income = 5000;

mgr.print();
console.log(`Tax Payable ${mgr.getTax()}`);