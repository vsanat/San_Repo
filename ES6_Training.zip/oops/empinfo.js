//DTO OR Entity
class EmployeeInfo{
    constructor(eno,ename,sal,dname,desig){
        this.EmpNo = eno;
        this.EmpName = ename;
        this.Salary = sal;
        this.DeptName = dname;
        this.Designation = desig;
    }
}
class EmployeeCRUD{
    constructor(){
        this.Employees = [];
    }
    save(eno,ename,sal,dname,desig){
        this.Employees.push({
            EmpNo:eno,
            EmpName:ename,
            Salary:sal,
            DeptName:dname,
            Designation:desig
        });
        return this.Employees;
    }
}