class MathClass{
    //Parameterized Constructor
    //the X and Y are public members of class 
    constructor(x,y){
        this.X = x;
        this.Y = y;
    }
    add(){
        let numX = parseInt(this.X);
        return numX + this.Y;
    }
    sub(){
        return this.X - this.Y;
    }
    div(){
        return this.X / this.Y;
    }
    mult(){
        return this.X * this.Y;
    }
}

let objm1 = new MathClass('100',200);
console.log(`Add =   ${objm1.add()}`);
console.log(`Sub =  ${objm1.sub()}`);
console.log(`Div =  ${objm1.div()}`);
console.log(`Mult =  ${objm1.mult()}`);