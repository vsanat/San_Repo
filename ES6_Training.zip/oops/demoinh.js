class baseClass{
    add123(x,y){
        return x+y;
    }
}
class deriveClass extends baseClass{
    constructor(){
        super();
    }
    add(x,y,z){
        return x+y+z;
   }
}

let objD = new deriveClass();
console.log(`2 Parameters ${objD.add(2,3)}`);
console.log(`3 Parameters ${objD.add(2,3,4)}`);