function doWork(condition){
    if(condition){
        let x = 100; //x is scopped inside if..statement
        console.log('Res = ' + x);
        for(let i=0;i<4;i++){
            console.log('In loop i = ' + i);
        } 
        console.log('Out of loop i = ' + i);
    }
    console.log('Res = ' + x);
}

doWork(true);
doWork(false);