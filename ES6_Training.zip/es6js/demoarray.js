let arrActors = [
    "sean connery","george luznaby","roger moore","trimothy dalton",
    "pierve brosnon","daniel craig"
];

//traditional iteration
for(let a; a<=arrActors.length;a++){
    console.log('Traditional Actor ' + arrActors[a]);
}
console.log();
//Iteration as per ES 3 ==> the "in" is iterator operator based on index
for(let a in arrActors){
    console.log('ES 3 Actor ' + arrActors[a]);
}
console.log();
//ES 6 Iterations using for..of loop
//It is index and data based iteration
for(let a of arrActors){
    console.log('ES 6 Actor = ' + a)
}
console.log();
//Using ES 5 and 6 Array functions
arrActors.forEach(function(a){
  console.log(' using array function ' + a);
});



