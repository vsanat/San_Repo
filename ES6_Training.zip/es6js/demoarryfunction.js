let moviesData =[];
let movies = {
    actor:'',
    list:[]
};



movies.actor = "sean connery";
movies.list.push("Dr.No");
movies.list.push("Thunderball");
movies.list.push("From Russia with Love");
movies.list.push("Dimonds are forever");

moviesData.push(movies);

movies.actor = "daniel craig";
movies.list.push("Casino Royal");
movies.list.push("Spectre");
movies.list.push("Skyfall");
movies.list.push("Quantum of Solace");

moviesData.push(movies);

console.log(JSON.stringify(moviesData));
