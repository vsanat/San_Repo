let dSet = new Set();
dSet.add('Tejas');
dSet.add('Mahesh');
dSet.add('Ramesh');
dSet.add('Ram');
dSet.add('Sabnis');
dSet.add('Mahesh'); //duplicate entry

dSet.forEach(function(v){
    console.log(v);
});

console.log(dSet.has('Mahesh'));
console.log(dSet.has('Mahesh123'));

for(let v of dSet.entries()){
    console.log(v);
}

var dMap = new Map();
dMap.set('A',{actor:'James Bond'});
dMap.set('B',{actor:'Jason Bourn'});
dMap.set('C',{actor:'Captain America'});

console.log(`${dMap.get('A')}`);

dMap.forEach((v,k)=>{
    console.log(`${k} ${JSON.stringify(v)}`);
});


