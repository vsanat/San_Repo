var handler = {
    //target: The Actual Object to be manipulated
    //prop: Property from target
    get:function(target,prop){
        return prop in target ?
            target[prop]:'Property is not in target';    
    }
};

var target = {
  x:0,y:0,z:0
};

//The Proxy object,
//First Parameter is target
//Second Paraneter is handle containing trap
//p act as a proxt for target object which is {}
let p = new Proxy(target,handler);
//Setting properties for target object.
p.x = 100;
p.y = 'Proxy Demo';
p.z = 1000;

console.log(`${p.x}  ${p.y}`);

console.log('z' in p,p.z);
