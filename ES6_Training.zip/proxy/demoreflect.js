var objData = {
   X:0,
   Y:0
};

for(var p in objData ){
    console.log(p + " " + objData[p]);
}