class EmployeeValid{
    constructor(){
        this.EmpNo=0;
        this.EmpName ='';
    }
}
//================PROXY===================
//1. trap handler
//2. Target Object being trapped

let vaidatorHandler = {
    //obj ==> Target
    //prop ==> Property name
    //value ==> Property value
    set:function(obj,prop,value){
        if(prop==='EmpNo'){
            if(!Number.isInteger(value)||value <0){
                throw new TypeError('The value for EmpNo must positive be integer');
            }
        }
       
        //set the value for property
        obj[prop] =value;
        return true;
    }
};
//===============CONSUMER=================

let emp = new EmployeeValid();
//Set the Proxy to the handler
let empProxy = new Proxy(emp,vaidatorHandler);

empProxy.EmpNo = 'Mahesh Sabnis';
 
empProxy.EmpName = 'Mahesh';


