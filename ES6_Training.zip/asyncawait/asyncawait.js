var request = require('request');

function getEmployees(){
  return new Promise((resolve,reject)=>{
      request('https://mydataservice001.azurewebsites.net/api/EmployeeInfoRESTAPI',(err,res,body)=>{
            if(err){
                reject(err); return;
            } 
            resolve(body);
      });
  });
};

// var res = getEmployees().then((resp)=>console.log(JSON.stringify(resp)));
// console.log(`The Result is
//   $(res)
// `);
printResponse();
async function printResponse(){
 var resp = await getEmployees();
 console.log(`async await ${resp}`);
}

