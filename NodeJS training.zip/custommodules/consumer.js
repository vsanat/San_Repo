var mdl = require('./mathmodule');
console.log(' Add ' + mdl.add(2,3));
console.log(' sub ' + mdl.sub(5,3));
var mdl1= require('./separateexportable');
console.log(' mult   ' + mdl1.mult(100,20000));
 
