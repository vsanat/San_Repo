exports.mult =  function(x,y){
    return x*y;
};

module.exports.div =  function(x,y){
    return x/y;
};