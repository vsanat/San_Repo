﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    //same method is present in both the interfaces, which one will be called by derived class?
    //ans is - only once we have to implement the method and compiler will anderstand that both he methods 
    //are implemented. 
    interface I1
    {
        void InterfcMethod();
    }

    interface I2
    {
        void InterfcMethod();
    }

    class ExplicitInterface : I1, I2
    {
        void I1.InterfcMethod() //we dont need access modifier
        {
            Console.WriteLine("Intereface I1 method");
        }

        public void InterfcMethod() //we can have access modifier
        {
            Console.WriteLine("Default method");
        }

        void I2.InterfcMethod() //we dont need access modifier
        {
            Console.WriteLine("Intereface I2 method");
        }

        static void Main()
        {
            I1 i1 = new ExplicitInterface();
            I2 i2 = new ExplicitInterface();

            i1.InterfcMethod();
            i2.InterfcMethod();

            ExplicitInterface exi = new ExplicitInterface();
            exi.InterfcMethod();

            Console.ReadLine();
        }
    }
}
