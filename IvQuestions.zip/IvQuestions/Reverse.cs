﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    class Reverse
    {
        static void Main1()
        {
            string text = "My name is San";
            string[] str = text.Split(' ');
            
            for (int i = str.Count()-1; i > 0; i--)
            {
                Console.Write(str[i]+" ");
            }
            
            var v = text.Split(' ').Reverse();
            text = String.Join(" ", v);

            string st = "Hello X";
            char[] ch = st.ToCharArray();
            for (int i = ch.Count() -1; i >= 0;i-- )
                Console.Write(ch[i]);

            Console.Read();
        }
    }
}
