﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace IvQuestions
{
    class VolatileExample
    {
        //volatile bool _loop = true;
         bool _loop = true;
        static void Main1(string[] args)
        {
            VolatileExample o1 = new VolatileExample();
            Thread t1 = new Thread(SomeThread);
            t1.Start(o1);
            Thread.Sleep(2000);
            o1._loop = false;
            Console.WriteLine("Value Set to false");            
       }
        private static void SomeThread(object o1)
        {
            VolatileExample o = (VolatileExample)o1;
            Console.WriteLine("Loop Starting...");
            while (o._loop)
            {               
            }
            Console.WriteLine("Loop Stopping...");
        }
    }
}
