﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class MyGenericCls<AnyDataType>
    {
        public void GetTypeOfData(AnyDataType d1 , AnyDataType d2)
        {
            Console.WriteLine(typeof(AnyDataType));
        }
    }

    class CallMyGenericCls
    {
        static void Main1()
        {
            MyGenericCls<int> mygen = new MyGenericCls<int>();
            mygen.GetTypeOfData(5,6);

            MyGenericCls<string> mygen1 = new MyGenericCls<string>();
            mygen1.GetTypeOfData("A","B");

            //base class reference derived class object
            //compile time overloading
            IList<string> strIList = new List<string>();          

            strIList.Add("san");
            strIList.Add("man");
            strIList.Add("wan");
            strIList.Add("dan");
            strIList.Add("fan");

            foreach (var item in strIList)
            {
                Console.WriteLine(item);
            }


            IEnumerable<string> strIList1 = new List<string>() { "1san","1man","1dan"};//during declaration we can provide values

            //adding and removing dynamically is not possible with IEnumerable
            //strIList1.Add("1san");
            //strIList1.Add("1man");
            
            Console.Read();
        }
    }
}
