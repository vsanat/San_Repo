﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class DoWhileExample
    {
        static void Main1()
        {
            #region dowhile example
            string yn;
            do
            {
                Console.WriteLine("Hello world!");
                Console.WriteLine("Want to continue: yes/no?");

                yn = Console.ReadLine();
            }
            while (yn == "yes");
            #endregion

            #region while example
            bool something = true;
            while (something)
            {
                Console.WriteLine("want to continue: true/false?");
                bool.TryParse(Console.ReadLine(), out something);
            }
            #endregion
        }
    }
}
