﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    class ParamsExample
    {
        public static void Fun(int i, int j, int k, params object[] par)
        {
            int res = i + j + k;

            foreach (int l in par)
            {
                res += l;
            }
            Console.WriteLine(res);
        }

        static public int addTwoEach(int[] args)
        {
            int sum = 0;
            foreach (var item in args)
                sum += item + 2;
            return sum;
        }

        static public int addTwoEach2(params int[] args)
        {
            int sum = 0;
            foreach (var item in args)
                sum += item + 2;
            return sum;
        }

        public static void Main1()
        {
            Fun(3, 2, 1, new object[] { 1, 2, 3, 4, 5 },5);
            Fun(1,3,4,5,6,6,7,8,9);

            //addTwoEach(1, 2); <-- not possible, we have to pass array
            addTwoEach(new int[]{1,2,3});
            addTwoEach2( 1, 2, 3 );
            Console.Read();
        }
    }
}
