﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class EnumExample
    {
        static void Main1()
        {
            Console.WriteLine(Gender.Female);
            Console.WriteLine(Gender.Male);
            Console.WriteLine(Gender.Unknown);
            Console.WriteLine((int)Gender.Male);
            Console.WriteLine((int)Gender.Unknown);           
            
            Console.Read();
        }
    }

    public enum Gender
    {
        Unknown=3,
        Male = 3,
        Female = 4
    }
}
