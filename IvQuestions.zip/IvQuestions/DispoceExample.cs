﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class DispoceExample
    {       
        static void Main1()
        {
            Emp e = new Emp();
            try
            {
                ((IDisposable)e).Dispose();
            }
            catch (Exception ex)
            {
                string s = ex.ToString();
                throw;
            }            

            e.Name = "";
        }
    }
}
