﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class clsA
    {
        static List<int> lstInt;
       static void Fun1()
        {
            Console.WriteLine("fun1");
            foreach (var item in  Fun2())
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("fun1 completed");
        }

        static IEnumerable<int> Fun2()
        {            
            Console.WriteLine("yield statred.");
            foreach (int item in lstInt) //every iteration yield will get called
            {
                if(item>5)
                yield return item;
            }
            Console.WriteLine( "yield completed.");
            //return 6; //cant write return outside the loop
            //return lstInt;
        }

        //same behaviour with IEnumerator
        static void Fun3(IEnumerator<int> o)
        {
            while (o.MoveNext())
            {
                Console.WriteLine(o.Current);
                if (o.Current > 5)
                    Fun4(o); //this sends the list whose current value starts with 6
            }
        }

        static void Fun4(IEnumerator<int> o)
        {
            while(o.MoveNext())
            {
                Console.WriteLine(o.Current);
            }
        }

        static void Main1(string[] args)
        {
            lstInt = new List<int>() {1,2,3,4,5,6,7,8,9 };

            Fun1();

            IEnumerator<int> o = lstInt.GetEnumerator();
            Fun3(o);
            Console.Read();
        }
    }
}
