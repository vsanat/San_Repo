﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    public delegate int MyDeligate(int i);
    class SyncAsyncDelegate
    {
        // public event MyDeligate MyEvent;

        //event handler
        public int MyFunction(int i)
        { 
            Console.WriteLine("MyFunction called: " + i);
            return 1;
        }

        public int MyFunction1(int i)
        {
            Console.WriteLine("MyFunction1 called: " + i);
            return 2;
        }

        public int MyFunction2(int i)
        {
            Console.WriteLine("MyFunction2 called: " + i);
            return 3;
        }

        public static void Main1()
        {
            SyncAsyncDelegate sad = new SyncAsyncDelegate();

            MyDeligate myDel = new MyDeligate(sad.MyFunction);
            myDel += sad.MyFunction1;
            myDel += sad.MyFunction2;

            Console.WriteLine(myDel.Invoke(9)); 
            //myDel.BeginInvoke(9); //multicast delegate cant be called async

            Console.Read();
        }
    }
}