﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    sealed class MySingletonClass
    {
        private MySingletonClass() { }

        public static int i = 5;
        public string str = "san";
        private static MySingletonClass myVar;
        private static object obj = new object();

        public static MySingletonClass GetSingletonObj
        {
            get
            {
                lock (obj) //thread safe singleton obj
                {
                    if (myVar == null)
                    {
                        myVar = new MySingletonClass();
                    }
                    return myVar;
                }
            }
        }
    }

    class Test1
    {
        public void Fun()
        {
            MySingletonClass single = MySingletonClass.GetSingletonObj;
            Console.WriteLine("child calss: " + single.str);
            single.str = "wan";
        }
    }

    class Test
    {
        public static void Main1(string[] args)
        {
            MySingletonClass single = MySingletonClass.GetSingletonObj;
            //Console.WriteLine(MySingletonClass.i);
            Console.WriteLine("parent class: " + single.str);
            single.str = "man";

            Test1 t1 = new Test1();
            t1.Fun();

            Console.WriteLine("modified in the child: " + single.str);
            Console.Read();
        }
    }
}
