﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


namespace InterviewQuestions
{
    class ThreadLock123
    {
        static void Main1(string[] args)
        {
            object obj = new object();
            Monitor.Enter(obj);
            Monitor.Exit(obj);

            Queue<string> q = new Queue<string>(); q.Enqueue("S");
            q.Enqueue("S");
            q.Enqueue("A");
            q.Enqueue("N");
            q.Enqueue("A");
            q.Enqueue("T");

            List<string> ls = new List<string> { "s","a","n","a","t"};
            ls.ForEach(s => Console.WriteLine(s));            

            q.ToList().ForEach(l=>Console.WriteLine(l));

            Console.Read();
        }
    }
}
