﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class OrdinalsExample
    {
        static void Main1()
        {
            string[] ordinals = new string[] { "First","Second","Third","Fourth"};
           
            IEnumerable<string> taken = ordinals.Take(3); //it will take first 3 elements of the array
            
            Console.WriteLine(taken.Count());
            foreach (var item in taken)
            {
                Console.WriteLine(item);
            }

            // or in short form

            foreach (string item in ordinals.Take(3))
            {
                Console.WriteLine(item);
            }

            //var v1 = (new A()).c();
            //var v2 = (new A()).GetHashCode();
        }
    }
}
