﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class A
    {
        public virtual void Test() { Console.WriteLine("A::Test()"); }
    }

    class B : A
    {
        public override void Test() { Console.WriteLine("B::Test()"); }
    }

    class C : B
    {
        public new void Test() { Console.WriteLine("C::Test()"); } //where ever I use new, method will be hidden
    }

    class Program
    {
        //static void Main(string[] args)
        //{

        //    A a = new A();
        //    B b = new B();
        //    C c = new C();

        //    a.Test(); // output --> "A::Test()"
        //    b.Test(); // output --> "B::Test()"
        //    c.Test(); // output --> "C::Test()"

        //    a = new B(); // parent reference, child object
        //    a.Test(); // output --> "A::Test()"

        //    b = new C();
        //    b.Test(); // output --> "B::Test()"

        //    Console.ReadKey();
        //}
    }
}
