﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class String_string_builder
    {
        //public static void Main(string[] args)
        //{
        //    string str = "hi";
        //    // create a new string instance instead of changing the old one

        //    str += "test";
        //    str += "help";


        //    StringBuilder sb = new StringBuilder("fluk");
        //    sb.Append("hi");
        //    sb.Append("test");
        //    string str1 = sb.ToString();
        //    Console.WriteLine(str1);
        //    Console.Read();
        //}
    }
}
