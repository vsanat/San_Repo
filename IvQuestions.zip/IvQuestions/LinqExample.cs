﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    class Emp
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
    }

    class LinqExample
    {
        public static void Main1()
        {
            List<Emp> lstEmp = new List<Emp> { 
            new Emp 
            { 
                EmpId = 1, 
                EmpName = "San" 
            },
            new Emp 
            { 
                EmpId = 1, 
                EmpName = "Man" 
            }
            };

            var res = from e in lstEmp
                            where e.EmpName.StartsWith("S")
                            select e.EmpName;

            //List<string> res1 = (from e in lstEmp
            //                     where e.EmpName.StartsWith("S")
            //                     select e.EmpName).ToList();
            //res1.ForEach(r => Console.WriteLine(r.em));

           Emp em = lstEmp.SingleOrDefault((l => l.EmpName.StartsWith("S")));

           var em1 = lstEmp.Where((l => l.EmpName.StartsWith("S")));
            foreach(var e in em1)//true or false is we use Select in place of Where
                Console.WriteLine(e.EmpName);

           Console.Read();
        }
    }
}
