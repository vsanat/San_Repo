﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    interface IService
    {
        void Serve(); 
    }

    class Service1 : IService
    {
        public void Serve()
        {
            Console.WriteLine("Service1 started...");
        }
    }

    class Service2 : IService
    {
        public void Serve()
        {
            Console.WriteLine("Service2 started...");
        }
    }


    class Client
    {
        IService iservice;

        //constructor DI
        public Client(IService iserv)
        {
            this.iservice = iserv;
        }

        public void Start()
        {
            Console.WriteLine("Starting the service");
            iservice.Serve();
        }
    }

    class Program
    {
        static void Main1()
        {
            //here Service is a dependency objct for client
            //client is decoupled 
            //maintainability is easy, we can easily modify the service logic 
            //service class just needs to implement IService interface

            Client client1 = new Client(new Service1()); //client doesnt know about service class now
            client1.Start();

            Client client2 = new Client(new Service2()); //client doesnt know about service class now
            client2.Start();
        }
    }
}
