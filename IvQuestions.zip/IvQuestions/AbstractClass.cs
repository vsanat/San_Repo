﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    //Creating an Abstract Class
    abstract class absClass
    {
        //A Non abstract method
        public int AddTwoNumbers(int Num1, int Num2)
        {
            return Num1 + Num2;
        }

        public absClass()
        {
            Console.WriteLine("we can have constructor in abs class");
        }

        //An abstract method, to be
        //overridden in derived class
        public abstract int MultiplyTwoNumbers(int Num1, int Num2);
    }

    //A Child Class of absClass
    class absDerived : absClass
    {
        [STAThread]
        static void Main1(string[] args)
        {
            //cretating instance of abstract class is not possible
            //absClass abc = new absClass();
            //You can create an
            //instance of the derived class
            
            //absClass ab = new absClass();

            absClass calculate = new absDerived();
            int added = calculate.AddTwoNumbers(10, 20);
            int multiplied = calculate.MultiplyTwoNumbers(10, 20);
            Console.WriteLine("Added : {0},Multiplied : {1}", added, multiplied);
            Console.Read();
        }

        //using override keyword,
        //implementing the abstract method
        //MultiplyTwoNumbers
        public override int MultiplyTwoNumbers(int Num1, int Num2)
        {
            return Num1 * Num2;
        }
    }
    //Abstract Class1
    abstract class absClass1:ISan
    {
        public abstract int AddTwoNumbers(int Num1, int Num2);
        public abstract int MultiplyTwoNumbers(int Num1, int Num2);

        //abstract cls can inherit from interfc but reverce is not possible
        public int MyProperty
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
    }

    //Abstract Class2
    abstract class absClass2 : absClass1
    {
        //Implementing AddTwoNumbers
        public override int AddTwoNumbers(int Num1, int Num2)
        {
            return Num1 + Num2;
        }
            
        //public override int MultiplyTwoNumbers(int Num1, int Num2)
        //{
        //    throw new NotImplementedException();
        //}
    }

    //Derived class from absClass2
    //class absDerived : absClass2
    //{
    //    Implementing MultiplyTwoNumbers
    //    public override int MultiplyTwoNumbers(int Num1, int Num2)
    //    {
    //        return Num1 * Num2;
    //    }
    //}

    interface ISan
    {
       // int i;
       // ISan() { }
        int MyProperty { get; set; }
    }
}
