﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class StaticClass
    {
        public static int i = 5;

        static StaticClass()
        {
            Console.WriteLine("test"); 
        }

        public StaticClass()
        {
            Console.WriteLine("test1");
        }
    }

    public class Abc
    {
        public static void Main1(string[] args)
        {
            ////we cant create instance of static class, but static constructor will be called automatically
            //StaticClass sc = new StaticClass();
            //Abc ab = new Abc();
            StaticClass stc = new StaticClass();
            Console.WriteLine("const created");
            //Console.WriteLine(StaticClass.i);

            Console.Read();
        }
    }
}
