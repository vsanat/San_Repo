﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public delegate int DelegatSample(int a, int b);
    public delegate void MultiDelegate(int a, int b);
    public class Sampleclass
    {
        public int Add1(int x, int y)
        {
            return x + y;
        }
        public int Sub1(int x, int y)
        {
            return x + y;
        }

        static void Main1(string[] args)
        {
            Sampleclass sc = new Sampleclass();

            DelegatSample delgate1 = sc.Add1;
            int i = delgate1(10, 20);
            Console.WriteLine(i);

            i = delgate1.Invoke(5, 12);
            Console.WriteLine(i);

            DelegatSample delgate2 = sc.Sub1;
            int j = delgate2(20, 10);
            Console.WriteLine(j);

            //anonymous method //we need the delegate to be defined of the same signature 
            DelegatSample delsam = delegate(int l, int m)
            {
                return l + m;
            };
            Console.WriteLine(delsam.Invoke(12, 13));

            //multicasting delegate
            MultiDelegate mulDel = Sampleclass.Add;
            mulDel += Sampleclass.Sub;
            mulDel += Sampleclass.Mul;

            //mulDel.Invoke(10,20);
            //or
            mulDel(5, 10);
            //or
            IAsyncResult res = mulDel.BeginInvoke(5, 10, null, null);

            DelegatSample ds = delegate(int ik, int jk) { return ik + jk; };
            
            Console.Read();
        }
       
        public static void Add(int x, int y)
        {
            Console.WriteLine("Addition Value: " + (x + y));
        }
        public static void Sub(int x, int y)
        {
            Console.WriteLine("Subtraction Value: " + (x - y));
        }
        public static void Mul(int x, int y)
        {
            Console.WriteLine("Multiply Value: " + (x * y));
        }

        ////////////////////////////////////////////////////////////////////////
        public void MyFun(DelegatSample del , int i)
        {
            int l = del.Invoke(10,10);
        }
        
    }
}
