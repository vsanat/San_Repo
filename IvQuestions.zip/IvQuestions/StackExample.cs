﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InterviewQuestions
{
    public class StackExample
    {
        public static void Main1()
        {
            Employee e1 = new Employee() { EmpId = 1, EmpName = "San" };
            Employee e2 = new Employee() { EmpId = 2, EmpName = "Man" };
            Employee e3 = new Employee() { EmpId = 3, EmpName = "Wan" };
            Employee e4 = new Employee() { EmpId = 4, EmpName = "Dan" };

            Stack<Employee> stkEmp = new Stack<Employee>();


        }
    }
}