﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class ReadOnlyExample
    {
        private static readonly object obj1 = new object(); //this is possible to initialize where declare
        private static readonly object obj;
        private static readonly object obj2;

        //private static const int j = 5; // we cant make it static as it is by default static
        private const int j = 5;

        private static volatile int vol = 50;

        public ReadOnlyExample()
        {
           // obj = new object(); //this is not possible for readonly
            vol = 100;
        }
        static ReadOnlyExample()
        {
            obj2 = new object();//this is possible to assign readonly iside static constructor
            vol = 200;
        }

        static void Main1()
        {
            //obj2 = new object();
            const int i =5;
            vol = 300;
        }
    }
}
