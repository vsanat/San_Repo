﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    class abc
    {
        static readonly object _object = new object();
        static void TestLock()
        {
            lock (_object)
            {
                Thread.Sleep(100);
                Console.WriteLine("hello");
            }

            //or this way   
            try
            {
                Monitor.Enter(_object);
                Thread.Sleep(100);
                Console.WriteLine("yello");
            }
            finally
            {
                Monitor.Exit(_object);
            }
        }

        static void Main1(string[] args)
        {
            for (int i = 0; i < 10; i++)
            {
                Thread tr = new Thread(TestLock);
                tr.Start();

                //ThreadStart start = new ThreadStart(TestLock);
                //new Thread(start).Start();
            }

            Console.ReadLine();
        }
    }
}
