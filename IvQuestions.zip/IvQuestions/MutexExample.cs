﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace IvQuestions
{
    class MutexExample
    {
        private static Mutex mutex = new Mutex();
        private const int numThreads = 4;
        private static void UseCsharpcorner()
        {
            mutex.WaitOne();   // Wait until it is safe to enter.
            Console.WriteLine("{0} has entered in the C_sharpcorner.com",
                Thread.CurrentThread.Name);
            // Place code to access non-reentrant resources here.
            Thread.Sleep(10);    // Wait until it is safe to enter.
            Console.WriteLine("{0} is leaving the C_sharpcorner.com\r\n",
                Thread.CurrentThread.Name);
            mutex.ReleaseMutex();    // Release the Mutex.
        }
        static void Main1(string[] args)
        {
            for (int i = 0; i < numThreads; i++)
            {
                Thread mycorner = new Thread(new ThreadStart(UseCsharpcorner));
                mycorner.Name = String.Format("Thread{0}", i + 1);
                mycorner.Start();
            }
            Console.Read();
        }
    }

    class MonitorExample
    {
        static void Fun(int j)
        {
            object o = new object();
            int i = 9;

            try
            {
                Monitor.Enter(i);
            }
            finally
            {
                Thread.Sleep(100);
                Console.WriteLine("I am locked.");
                Thread.Sleep(100);
                Monitor.Exit(i);
            }           

            //lock (o)
            //{
            //    Thread.Sleep(500);
            //    Console.WriteLine("I am locked. " + j );
            //    Thread.Sleep(500);
            //}
        }

        static void Fun()
        {
            object o = new object();
            int i = 9;

            try
            {
                Monitor.Enter(o);
            }
            finally
            {
                Thread.Sleep(100);
                Console.WriteLine("I am locked.");
                Thread.Sleep(100);
                Monitor.Exit(o);
            }

            //lock (o)
            //{
            //    Thread.Sleep(500);
            //    Console.WriteLine("I am locked. " );
            //    Thread.Sleep(500);
            //}
        }

        static void Main1()
        {
            for (int i = 0; i < 10; i++)
            {
                //Fun();
                Thread tr = new Thread(new ThreadStart(Fun));
                tr.Start();
            }
        }
    }
    class WithLock
    {
        private static Mutex mutex = new Mutex();
        //private const int numhits = 1;
        static object o = new object();
        private const int numThreads = 4;
        //private static void ThreadProcess()
        //{
        //    for (int i = 0; i < numhits; i++)
        //    {
        //        UseCsharpcorner();
        //    }
        //}
        private static void UseCsharpcorner()
        {
            lock (o)
            {
                //mutex.WaitOne();   // Wait until it is safe to enter.
                Console.WriteLine("{0} has entered in the C_sharpcorner.com",
                    Thread.CurrentThread.Name);
                // Place code to access non-reentrant resources here.
                Thread.Sleep(10);    // Wait until it is safe to enter.
                Console.WriteLine("{0} is leaving the C_sharpcorner.com\r\n",
                    Thread.CurrentThread.Name);
                //mutex.ReleaseMutex();    // Release the Mutex.
            }
        }
        static void Main1(string[] args)
        {
            for (int i = 0; i < numThreads; i++)
            {
                Thread mycorner = new Thread(new ThreadStart(UseCsharpcorner));
                mycorner.Name = String.Format("Thread{0}", i + 1);
                mycorner.Start();
            }
            Console.Read();
        }
    }

    class LogicTest
    {
        static void Main1()//params string[] args)
        {
            string a = "-i";
            string b = "-v";
            string c = "-m";
            string d = "-s";
            
            //-i and -v togather
            //-s and -m not together

            Console.WriteLine("fdf");

            //foreach (string item in args)
            //{
            //    Console.WriteLine(item);
            //}            

            Console.ReadLine();
        }
    }
}
