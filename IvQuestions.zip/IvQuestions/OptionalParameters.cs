﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class OptionalParameters
    {
        static void Main1()
        {
            Console.WriteLine(AddNumbers(10, 20));
            Console.WriteLine(AddNumbers(10, 20, 30));
            Console.WriteLine(AddNumbers(10, 20, new int[] { 30, 40 }));
            int[] k = new int[] { 2, 4 };
            Console.WriteLine(AddNumbers(10, 20, k));

            Console.WriteLine(AddNumbers1(10, 20));
            //Console.WriteLine(AddNumbers1(10, 20, 30));
            Console.WriteLine(AddNumbers1(10, 20, new int[] { 30 }));
            Console.WriteLine(AddNumbers1(10, 20, new int[] { 30, 40 }));

            Console.WriteLine(AddNumbers2(10, 20));
            Console.WriteLine(AddNumbers2(10, 20, 30));
            Console.WriteLine(AddNumbers2(10, 20, d: 10)); //not providing value for c but for d
            Console.WriteLine(AddNumbers2(10, 20, d: 10, c: 20)); //providing value for c and d

            Console.Read();
        }

        public static int AddNumbers2(int i, int j, int c = 4, int d = 5) //we can keep optional parameters only at last 
        {
            int res = i + j + c + d;

            return res;
        }

        //giving default value to the paramter
        public static int AddNumbers1(int i, int j, int[] nums = null)
        {
            int res = i + j;
            if (nums != null)
                foreach (int item in nums)
                {
                    res += item;
                }
            return res;
        }

        //making optional parameters using params
        public static int AddNumbers(int i, int j, params int[] nums)
        {
            int res = i + j;
            if (nums != null)
                foreach (int item in nums)
                {
                    res += item;
                }
            return res;
        }
    }
}
