﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Sample
    {
        public string param1, param2;
        static int i;

        static Sample() //Public -- access modifier is not allowed
        {
            i = 40;
            Console.WriteLine("Hi this is Static Constructor");
        }
        public Sample()
        {
            //param1 = "Sample";
            //param2 = "Instance Constructor";
            Console.WriteLine("Hi this is instance Constructor");
        }

        public Sample(string s)
        {
            Console.WriteLine("base class constructor called: " + s);
        }

    }
    class Program1
    {
        static void Main1(string[] args)
        {
            // Here Both Static and instance constructors are invoked for first instance
            Sample obj = new Sample();
            Console.WriteLine(obj.param1 + " " + obj.param2);

            // Here only instance constructor will be invoked
            Sample obj1 = new Sample();
            Console.WriteLine(obj1.param1 + " " + obj1.param2);

            ThreadStart ts = new ThreadStart(Foo);
            //ts.Invoke();
            ts.BeginInvoke(null, null);
            //Foo();

            Program2 prg2 = new Program2();
            prg2.Foo1();
            Console.ReadLine();
        }
        static void Foo()
        {
            Sample obj = new Sample();
            Console.WriteLine(obj.param1 + " " + obj.param2);

            // Here only instance constructor will be invoked
            Sample obj1 = new Sample();
            Console.WriteLine(obj1.param1 + " " + obj1.param2);
        }
    }

    public class Program2
    {
        public void Foo1()
        {
            Sample obj = new Sample();
            Console.WriteLine(obj.param1 + " " + obj.param2);

            // Here only instance constructor will be invoked
            Sample obj1 = new Sample();
            Console.WriteLine(obj1.param1 + " " + obj1.param2);
        }
    }

    class Program3:Sample
    {
         public Program3():base("hello base")
        {
            Console.WriteLine("derived class ctor called");
        }
         static void Main1()
         {
             Program3 prg3 = new Program3();

             Console.ReadLine();
         }
    }
}
