﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    class BasePrint
    {
        public virtual void Print()
        { Console.WriteLine("BasePrint"); }
    }
    class DerivedPrint : BasePrint
    {
        public void Print()  //<-- its not mandatory to write override
        {
            Console.WriteLine("DerivedPrint");
        }

        //public new void Print()  //<-- 
        //{
        //    Console.WriteLine("DerivedPrint");
        //}

        //public override void Print()  //<--
        //{
        //    Console.WriteLine("DerivedPrint");
        //}
    }
    static class Prog
    {
        public static void Print(this BasePrint a)
        { Console.WriteLine("ExtendedBasePrint"); }

        static void Main1()
        {
            //BasePrint b = new BasePrint();
            //b.Print();
            DerivedPrint dp = new DerivedPrint();
            dp.Print();

            BasePrint dp1 = new DerivedPrint();
            dp1.Print();

            //Prog.Print(b);
            Console.Read();
        }
    }
}
