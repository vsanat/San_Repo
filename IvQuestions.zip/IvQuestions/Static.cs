﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class MyClass
    {
        // non-static instance member variable
        private int a;
        //static member variable
        private static int b;
        //static method
        public static void DoSomething()
        {
            //this will result in compilation error as “a” has no memory
            //a = a + 1;
            
            //this works fine
            MyClass mc = new MyClass();
            mc.a = mc.a + 1;
           
            //this works fine since “b” is static
            b = b + 1;

            //DoSomething2();
        }

        public void DoSomething2()
        {
            //this works fine
            a = a + 1;

            //this works fine since “b” is static
            b = b + 1;
        }
    }
}
