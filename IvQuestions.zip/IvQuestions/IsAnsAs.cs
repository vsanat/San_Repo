﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewQuestions
{
    class emp:Emp { }
    class IsAnsAs
    {
        int k;
        public static void Main1()
        {
            //int j = null;

            emp e = new emp();
            //string e;
            if(e is Emp)
                Console.WriteLine("true");

            var d = e as Emp;
            Console.Read();
        }
    }
}
