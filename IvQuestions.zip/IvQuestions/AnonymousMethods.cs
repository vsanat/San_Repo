﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IvQuestions
{
    public delegate int mydel(int i, int j);
    class AnonymousMethods //for any anonymous method we need a signature which is of delegate
    {
        void Foo()
        {
            mydel md = delegate(int k, int l) { return k + l; };

            //one more example
            //using Func <-- this is also called generic delegate
            Func<int, int, int> v1 = (x, y) => x + y;
            int r = v1(30,40);

            Func<int, int, int> v = (int x, int y) => {
                //blah
                return x + y;
            };
            int result = v(10, 20);

            //int m = md(4,5);
            //Console.WriteLine(m);

            //int m = md.Invoke(4,5);
            //Console.WriteLine(m);

            mydel md1 = delegate(int k, int l)
            {
                Console.WriteLine(k + l);
                return k + l;
            };

            //int r = md1.Invoke(3,4);
            IAsyncResult m = md.BeginInvoke(4, 5, null, null);
            Console.WriteLine(m);
        }

        public event mydel myeve;
        int Foo1(int j, int k)
        {
            Console.WriteLine(j + k);
            return j + k;
        }

        void Foo2()
        {
            AnonymousMethods ano = new AnonymousMethods();
            mydel md = new mydel(ano.Foo1);
            ano.myeve += Foo1;

            //anonymous method
            ano.myeve += delegate(int k, int l) { Console.WriteLine(k - l); return k + l; };
            ano.myeve(10, 5);

            //anonymous class
            var vr = new { studentid = 1, studentName = "san" };
            object ob = new { studentid = 1, studentName = "san" };
         }

        static void Main1()
        {
            AnonymousMethods and = new AnonymousMethods();
            and.Foo2();
            Console.Read();
        }
    }
}
