var http = require('http');
var fs = require('fs');

var server = http.createServer(function (req, res) {
    // var pg = fs.readFileSync('../views/home.html');
    // res.writeHead(200, {'Content-Type':'text/html'})
    // res.write(pg)
    // res.end();
    if (req.url === '/home') {
        fs.readFileSync('../views/home.html', function (err, pg) {
            if (err) {
                console.log('some error')
                res.writeHead(400, { 'Content-Type': 'text/html' });
                res.write('File not found')
                re.end();
            }
            else {
                console.log('no error')
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.write(pg)
                res.end();
            }
        });
    }
    else if (req.url === '/about') {
        fs.readFileSync('../views/about.html', function (err, pg) {
            if (err) {
                res.writeHead(400, { 'Content-Type': 'text/html' });
                res.write('File not found')
                re.end();
            }
            else {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.write(pg)
                res.end();
            }
        });
    }
    else {
        res.writeHead(400, { 'Content-Type': 'text/html' });
        res.write('Please check the URL.')
        res.end();
    }
});

server.listen(9090);
console.log('Started listening on 9090');