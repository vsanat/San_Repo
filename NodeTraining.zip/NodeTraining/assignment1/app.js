var http = require('http');
var fs = require('fs');

var productPage = fs.readFileSync('./index.html');

var server = http.createServer(function (req, resp) {

    //Get data
    if (req.method === "GET") {
        resp.writeHead(200, { 'content-type': 'text/html' });
        resp.end(productPage);
    }

    //Post data
    if (req.method === "POST") {
        var productData = '';

        req.on('data', function (prd) {
            productData += prd;
            var prodarr = productData.split('&');
           
            var validationResult = validateData(prodarr)
            if (validationResult.status == true) {
                saveData(prodarr);
            }
            else{
                resp.end(validationResult.message);
            }

        }).on('end', function () {
            resp.end('Data received  from you is ' + JSON.stringify(empList));
        });
    }
});

function validateData(prodarr) {
    for (var e in prodarr) {
        var res = prodarr[e].split('=');
        if(res[0] == 'empname'){
            var format = /[!@#$%^&*0-9()_+\-=\[\]{};':"\\|,.<>\/?]+/;
            if(format.test(res[1]))
            return { status: false, message: 'Invalid emp name' };           
        }

        if (res[0] == 'empid') {
            if (isNaN(res[1])) {
                //console.log('invalid emp id')
                return { status: false, message: 'Invalid emp id' };
            }
            else if(res[1]<0){
                return { status: false, message: 'Emp id cant be negative' };
            }
            else{
                var empexist = empList.filter(x => x.empid == res[1])
                if(empexist.length > 0)
                return { status: false, message: 'Emp id already exist' };
            }
        }
        if (res[0] == 'salary') {
            if (isNaN(res[1])) {
                return { status: false, message: 'Invalid salary' };
            }
            else if(res[1]<0){
                return { status: false, message: 'Salary cant be negative' };
            }
        }
    }
    return {status:true, message:'Success'};
}

function saveData(prodarr) {
    var emp = {};

    for (var e in prodarr) {
        var res = prodarr[e].split('=');
        if (res[0] == 'empid') {  
            emp.empid = res[1];         
        }
        if (res[0] == 'empname') {    
            emp.empname = res[1];        
        }
        if (res[0] == 'salary') {    
            emp.salary = res[1];        
        }
        if (res[0] == 'deptname') {    
            emp.deptname = res[1];        
        }
        if (res[0] == 'designation') {    
            emp.designation = res[1];        
        }
    }

    empList.push(emp);    
}

var empList = [];

server.listen(5050);
console.log('Server started on  5050');