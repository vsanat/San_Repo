var express = require('express');
var instance = express();
var bodyparser = require('body-parser');
var cors = require('cors');

//configure the body parser with express instance
instance.use(bodyparser.json());
//parse the body only from all type of JSON data
instance.use(bodyparser.urlencoded({ extended: false }))

//configure cors with express
// var options = {
//     "methods":"get,post,put,delete",
//     "origin":"http://"
//     "headers":
// }
instance.use(cors()); //this will allow request from any origin

var employee = {
    EmpNo: 0,
    EmpName: '',
    Salary: 0,
    DeptName: '',
    Designation: ''
}

var employees = [
    { EmpNo: 101, EmpName: 'San', Salary: 1000, DeptName: 'D1', Designation: 'Ds1' },
    { EmpNo: 102, EmpName: 'Man', Salary: 2000, DeptName: 'D1', Designation: 'Ds2' }
];

//creating REST APIs
instance.get('/api/employees', function (req, resp) {
    resp.status(200).send(JSON.stringify(employees));
});

instance.get('/api/employees/{id}', function (req, resp) {
    //Read the header parameter
    var id = req.params.id;
    //Search the record from array based on id
    for (var e in employees) {
        if (employees[e].EmpNo == id) {
            var selEmp = employees[e];
            resp
                .status(200)
                .send({
                    success: true,
                    data: JSON.stringify(selEmp)
                });
        }
    }
});

instance.post('/api/employees', function (req, resp) {
        //1. read the body
        var data = req.body;
        console.log(JSON.stringify(data));
        employees.push(data)

        resp.status(200).send({ success: true, data: JSON.stringify(employees) })
    })

// instance.put('/api/employees/:id', function(req, resp));
// instance.delete();

instance.listen(6070, function () {
    console.log('Server started @6070')
});