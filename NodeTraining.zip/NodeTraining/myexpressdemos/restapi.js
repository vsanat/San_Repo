var express = require('express');
var bodyparser = require('body-parser');
var instance = express();
var cors = require('cors');

//configure the body parser with express instance
instance.use(bodyparser.json());
//parse the body only from all type of JSON data
instance.use(bodyparser.urlencoded({ extended: false }))

instance.use(cors()); //this will allow request from any origin

//load CRUD logic modules
var logic = require('./crudlogic');

instance.get('/api/employees', logic.getall);
instance.get('/api/employees/:id', logic.getbyid);
instance.post('/api/employees', logic.save);

instance.listen(6070, function () {
    console.log('Server started @6070')
})