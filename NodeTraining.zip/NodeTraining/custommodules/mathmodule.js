module.exports = {
    add: function (x, y) { return x + y; },

    sub: function (x, y) { return x - y; }
}

