var mdl = require('./mathmodule');
var mdl1 = require('./sepereateexport')

console.log('Add', mdl.add(5,6));
console.log('Mult', mdl1.mult(5,6));