console.log('Hello world!!');

function add(x, y) {
    console.log(parseInt(x) + parseInt(y));
}

add(10, 20);

var names = ['San', 'Man', 'Dan'];

console.log(JSON.stringify(names))

for (var n in names)
    console.log(names[n])

var emps = [{ EmpNo: 101, EmpName: 'San' },
            { EmpNo: 102, EmpName: 'Man' },
            { EmpNo: 103, EmpName: 'Dan' },
            { EmpNo: 104, EmpName: 'Lan' }
]

console.log(JSON.stringify(emps))

emps.push({ EmpNo: 105, EmpName: 'Wan' })

for (var e in emps)
    console.log(JSON.stringify(emps[e]))