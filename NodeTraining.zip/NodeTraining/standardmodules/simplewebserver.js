//1. Load the https module
var http = require('http');

//2. Create server
// var server = http.createServer(function (req, res) {
//     res.writeHead(200, { 'Content-Type': 'text/html' });
//     res.write('<h2>Welcome the Node.js web server</h2>');
//     res.end();
// });


// server.listen(7080);
// console.log('Server started on 7080');

var emps = [{ EmpNo: 101, EmpName: 'San' },
    { EmpNo: 102, EmpName: 'Man' },
    { EmpNo: 103, EmpName: 'Dan' },
    { EmpNo: 104, EmpName: 'Lan' }
]

var server = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.write(JSON.stringify(emps));
    res.end();
});


server.listen(7080);
console.log('Server started on 7080');