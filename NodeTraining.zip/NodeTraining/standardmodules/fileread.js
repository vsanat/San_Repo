var fs = require('fs');

//1. read Synchronously
var data = fs.readdirSync('./myfile1.txt');
console.log('Synchronous reading')
console.log(data.toString());


console.log('Asynchronous reading')
fs.readFile('./myfile1.txt', function (err, data) {
    if (err) {
        console.log('Some error occured' + err.message)
        return;
    }

    console.log(data.toString())
})

console.log('Done!!!')

fs.writeFile('./myfile1.txt', 'The data to written', function(err){
    if(err){
        console.log('file write error' + err.message)
        return;
    }

    console.log('file created')
})