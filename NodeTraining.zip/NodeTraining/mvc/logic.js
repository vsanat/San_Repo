var employee = {
    EmpNo: 0,
    EmpName: '',
    Salary: 0,
    DeptName: '',
    Designation: ''
}

var employees = [
    { EmpNo: 101, EmpName: 'San', Salary: 1000, DeptName: 'D1', Designation: 'Ds1' },
    { EmpNo: 102, EmpName: 'Man', Salary: 2000, DeptName: 'D1', Designation: 'Ds2' }
];

exports.getall = function (req, resp) {
    resp.status(200).send(JSON.stringify(employees));
};

exports.getbyid = function (req, resp) {
    //Read the header parameter
    var id = req.params.id;
    //Search the record from array based on id
    for (var e in employees) {
        if (employees[e].EmpNo == id) {
            var selEmp = employees[e];
            resp
                .status(200)
                .send({
                    success: true,
                    data: JSON.stringify(selEmp)
                });
        }
    }
};

exports.save = function (req, resp) {
    //1. read the body
    var data = req.body;
    console.log(JSON.stringify(data));
    employees.push(data)

    resp.status(200).send({ success: true, data: JSON.stringify(employees) })
};