var express = require('express');
var bodyparser = require('body-parser');
var cors = require('cors');
var path = require('path');

var instance = express();
//configure static files with express and provide it to instance object
instance.use(express.static(path.join(__dirname + './../node_modules/jquery/dist')));
instance.use(express.static(path.join(__dirname + './../node_modules/bootstrap/dist/css')));
instance.use(express.static(path.join(__dirname + './../node_modules/bootstrap/dist/js')));

//declare router
var router = express.Router();

//define routes for views
router.get('/home', function(res, resp){
    resp.sendfile(path.join(__dirname + '/employee.html'));
})
// configure the router with express intstance
instance.use(router);

//configure the body parser with express instance
instance.use(bodyparser.json());

//parse the body only from all type of JSON data
instance.use(bodyparser.urlencoded({ extended: false }))

//load cors
instance.use(cors()); //this will allow request from any origin

//load CRUD logic modules
var logic = require('./logic');

instance.get('/api/employees', logic.getall);
instance.get('/api/employees/:id', logic.getbyid);
instance.post('/api/employees', logic.save);

instance.listen(6070, function () {
    console.log('Server started @6070')
})
